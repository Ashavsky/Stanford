package db;

/**
 * Created by Alex on 3/2/2016.
 */

public class MyDBInfo
{
    public static final String MYSQL_USERNAME = "ccs108ashavsky";
    public static final String MYSQL_PASSWORD = "L32WjQvXhHvTx9FX";
    public static final String MYSQL_DATABASE_SERVER = "mysql-user.stanford.edu";
    public static final String MYSQL_DATABASE_NAME = "c_cs108_ashavsky";
}
