USE c_cs108_ashavsky;

Drop Table UserDetail;
Drop Table UserFriends;
Drop Table UserSocial;
Drop Table UserNotes;
Drop Table UserChallenges;
Drop Table UserFriendRequests;
Drop Table UserAchievements;
Drop Table UserActivity;