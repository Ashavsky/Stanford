reccs:

-use tokenize.js for inputs in questions
-first pass through do not worry about persisting data - focus on models and views. I will take care of database
	ex of tasks: set up bootstrap, create certain pages, create answers interface and implementations, create quizz inetrface and implementations,
				 create user and concept of users, set up databases, draw out how persistence layer will work
-next pass through 