USE c_cs108_ashavsky;

Drop Table QuizSummary;
Drop Table QuizHistory;
Drop Table QuizStats;
Drop Table QuizQuestions;
Drop Table QuizAnswers;
