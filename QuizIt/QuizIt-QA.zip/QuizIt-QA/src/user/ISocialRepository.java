package user;

/**
 * Created by Alex on 3/7/2016.
 */
public interface ISocialRepository
{
}
