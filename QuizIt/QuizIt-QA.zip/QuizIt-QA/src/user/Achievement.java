package user;

/**
 * Created by scottparsons on 3/9/16.
 */
public class Achievement {
    public String name;
    public String description;
    public String date;

    public Achievement(String name, String description, String date) {
        this.name = name;
        this.description = description;
        this.date = date;
    }

}
