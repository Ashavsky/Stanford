package user;

/**
 * Created by scottparsons on 3/8/16.
 */
public class Announcement {
    public String text;
    public String date;

    public Announcement(String text, String date) {
        this.text = text;
        this.date = date;
    }
}
