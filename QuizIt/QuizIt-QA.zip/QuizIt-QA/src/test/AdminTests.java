package test;

/**
 * Created by Alex on 3/9/2016.
 */
public class AdminTests
{
}
